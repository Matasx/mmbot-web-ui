import Vue from 'vue'
import { BootstrapVue } from 'bootstrap-vue'

import './style/app.scss'

Vue.use(BootstrapVue)
