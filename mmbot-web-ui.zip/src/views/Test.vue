<template>
  <b-container>
    <h1>Sample page</h1>
  </b-container>
</template>
