<template>
  <b-container>
    <h1>Sign in</h1>
    <login-form></login-form>
  </b-container>
</template>

<script>
import LoginForm from '@/components/LoginForm.vue'

export default {
  components: { LoginForm }
}
</script>
