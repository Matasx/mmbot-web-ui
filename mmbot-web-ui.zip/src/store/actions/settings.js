export const SETTINGS_THEME_SET = 'SETTINGS_THEME_SET'
export const DARK_SKIN = 'dark_skin'
export const LIGHT_SKIN = 'light_skin'
